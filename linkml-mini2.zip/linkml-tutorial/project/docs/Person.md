
# Class: Person


Class for Person

URI: [linkml_tutorial:Person](https://w3id.org/tejasram365/linkml-tutorial/Person)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[Animal]<pets%200..*-%20[Person&#124;primary_email:string%20%3F;vital_status:string;id:string;name(i):string%20%3F;birth_date(i):date%20%3F;age_in_years(i):integer%20%3F],[PersonCollection]++-%20entries%200..*>[Person],[NamedThing]^-[Person],[PersonCollection],[NamedThing],[Animal])](https://yuml.me/diagram/nofunky;dir:TB/class/[Animal]<pets%200..*-%20[Person&#124;primary_email:string%20%3F;vital_status:string;id:string;name(i):string%20%3F;birth_date(i):date%20%3F;age_in_years(i):integer%20%3F],[PersonCollection]++-%20entries%200..*>[Person],[NamedThing]^-[Person],[PersonCollection],[NamedThing],[Animal])

## Identifier prefixes

 * orcid
 * WIKIDATA

## Parents

 *  is_a: [NamedThing](NamedThing.md) - The most generic type of entity that has a name

## Referenced by Class

 *  **None** *[entries](entries.md)*  <sub>0..\*</sub>  **[Person](Person.md)**

## Attributes


### Own

 * [primary_email](primary_email.md)  <sub>0..1</sub>
     * Description: The main email address of a person
     * Range: [String](types/String.md)
 * [vital_status](vital_status.md)  <sub>1..1</sub>
     * Description: living or dead status
     * Range: [String](types/String.md)
 * [pets](pets.md)  <sub>0..\*</sub>
     * Description: a collection of animals that lives with and is taken care of by a person.
     * Range: [Animal](Animal.md)
 * [Person➞id](Person_id.md)  <sub>1..1</sub>
     * Description: this is a unique identifier for a person.
     * Range: [String](types/String.md)

### Inherited from NamedThing:

 * [name](name.md)  <sub>0..1</sub>
     * Description: A human-readable name for a person
     * Range: [String](types/String.md)
 * [birth date](birth_date.md)  <sub>0..1</sub>
     * Description: Date on which a person is born
     * Range: [Date](types/Date.md)
 * [age_in_years](age_in_years.md)  <sub>0..1</sub>
     * Description: Number of years since birth
     * Range: [Integer](types/Integer.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | schema:Person |
| **Exact Mappings:** | | schema:Person |
|  | | biolink:Person |
|  | | foaf:Person |
|  | | WIKIDATA:Q215627 |
|  | | WIKIDATA:Q5 |

