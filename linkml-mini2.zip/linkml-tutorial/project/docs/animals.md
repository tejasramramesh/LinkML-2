
# Slot: animals


A collection of animals

URI: [linkml_tutorial:animals](https://w3id.org/tejasram365/linkml-tutorial/animals)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Animal](Animal.md)

## Parents


## Children


## Used by

 * [AnimalCollection](AnimalCollection.md)
