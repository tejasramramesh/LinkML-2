
# Slot: id


A unique identifier for a person

URI: [linkml_tutorial:id](https://w3id.org/tejasram365/linkml-tutorial/id)


## Domain and Range

None &#8594;  <sub>1..1</sub> [String](types/String.md)

## Parents


## Children

 *  [Person➞id](Person_id.md)

## Used by

 * [Animal](Animal.md)
 * [NamedThing](NamedThing.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | schema:identifier |

