
# Slot: species


The species of an animal

URI: [linkml_tutorial:species](https://w3id.org/tejasram365/linkml-tutorial/species)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Uriorcurie](types/Uriorcurie.md)

## Parents


## Children


## Used by

 * [Animal](Animal.md)
