
# Slot: entries


A collection of things

URI: [linkml_tutorial:entries](https://w3id.org/tejasram365/linkml-tutorial/entries)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Person](Person.md)

## Parents


## Children


## Used by

 * [PersonCollection](PersonCollection.md)
