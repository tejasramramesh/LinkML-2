
# Class: AnimalCollection


A collection of Animals

URI: [linkml_tutorial:AnimalCollection](https://w3id.org/tejasram365/linkml-tutorial/AnimalCollection)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[Animal]<animals%200..*-++[AnimalCollection],[Animal])](https://yuml.me/diagram/nofunky;dir:TB/class/[Animal]<animals%200..*-++[AnimalCollection],[Animal])

## Attributes


### Own

 * [animals](animals.md)  <sub>0..\*</sub>
     * Description: A collection of animals
     * Range: [Animal](Animal.md)
