
# Class: NamedThing


The most generic type of entity that has a name

URI: [linkml_tutorial:NamedThing](https://w3id.org/tejasram365/linkml-tutorial/NamedThing)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[Person],[NamedThing&#124;id:string;name:string%20%3F;birth_date:date%20%3F;age_in_years:integer%20%3F]^-[Person],[NamedThing]^-[Animal],[Animal])](https://yuml.me/diagram/nofunky;dir:TB/class/[Person],[NamedThing&#124;id:string;name:string%20%3F;birth_date:date%20%3F;age_in_years:integer%20%3F]^-[Person],[NamedThing]^-[Animal],[Animal])

## Children

 * [Animal](Animal.md) - Class for animals
 * [Person](Person.md) - Class for Person

## Referenced by Class


## Attributes


### Own

 * [id](id.md)  <sub>1..1</sub>
     * Description: A unique identifier for a person
     * Range: [String](types/String.md)
 * [name](name.md)  <sub>0..1</sub>
     * Description: A human-readable name for a person
     * Range: [String](types/String.md)
 * [birth date](birth_date.md)  <sub>0..1</sub>
     * Description: Date on which a person is born
     * Range: [Date](types/Date.md)
 * [age_in_years](age_in_years.md)  <sub>0..1</sub>
     * Description: Number of years since birth
     * Range: [Integer](types/Integer.md)
