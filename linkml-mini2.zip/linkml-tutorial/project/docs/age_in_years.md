
# Slot: age_in_years


Number of years since birth

URI: [linkml_tutorial:age_in_years](https://w3id.org/tejasram365/linkml-tutorial/age_in_years)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [Animal](Animal.md)
 * [NamedThing](NamedThing.md)
 * [Person](Person.md)
