
# Slot: name


A human-readable name for a person

URI: [linkml_tutorial:name](https://w3id.org/tejasram365/linkml-tutorial/name)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Animal](Animal.md)
 * [NamedThing](NamedThing.md)
 * [Person](Person.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | schema:name |

