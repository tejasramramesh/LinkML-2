
# Type: nodeidentifier


A URI, CURIE or BNODE that represents a node in a model.

URI: [linkml:Nodeidentifier](https://w3id.org/linkml/Nodeidentifier)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **NodeIdentifier** |
| Representation | | str |
