
# Type: curie


a compact URI

URI: [linkml:Curie](https://w3id.org/linkml/Curie)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **Curie** |
| Representation | | str |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Comments:** | | in RDF serializations this MUST be expanded to a URI |
|  | | in non-RDF serializations MAY be serialized as the compact representation |

