
# Type: datetime


The combination of a date and time

URI: [linkml:Datetime](https://w3id.org/linkml/Datetime)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **XSDDateTime** |
| Representation | | str |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Exact Mappings:** | | schema:DateTime |

