
# Type: string


A character string

URI: [linkml:String](https://w3id.org/linkml/String)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **str** |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Exact Mappings:** | | schema:Text |

