
# Slot: pets


a collection of animals that lives with and is taken care of by a person.

URI: [linkml_tutorial:pets](https://w3id.org/tejasram365/linkml-tutorial/pets)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Animal](Animal.md)

## Parents


## Children


## Used by

 * [Person](Person.md)
