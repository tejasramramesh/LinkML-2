
# Class: Animal


Class for animals

URI: [linkml_tutorial:Animal](https://w3id.org/tejasram365/linkml-tutorial/Animal)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[NamedThing],[AnimalCollection]++-%20animals%200..*>[Animal&#124;species:uriorcurie%20%3F;breed:uriorcurie%20%3F;color:string%20%3F;weight_in_mgs:string%20%3F;id(i):string;name(i):string%20%3F;birth_date(i):date%20%3F;age_in_years(i):integer%20%3F],[Person]-%20pets%200..*>[Animal],[NamedThing]^-[Animal],[Person],[AnimalCollection])](https://yuml.me/diagram/nofunky;dir:TB/class/[NamedThing],[AnimalCollection]++-%20animals%200..*>[Animal&#124;species:uriorcurie%20%3F;breed:uriorcurie%20%3F;color:string%20%3F;weight_in_mgs:string%20%3F;id(i):string;name(i):string%20%3F;birth_date(i):date%20%3F;age_in_years(i):integer%20%3F],[Person]-%20pets%200..*>[Animal],[NamedThing]^-[Animal],[Person],[AnimalCollection])

## Parents

 *  is_a: [NamedThing](NamedThing.md) - The most generic type of entity that has a name

## Referenced by Class

 *  **None** *[animals](animals.md)*  <sub>0..\*</sub>  **[Animal](Animal.md)**
 *  **None** *[pets](pets.md)*  <sub>0..\*</sub>  **[Animal](Animal.md)**

## Attributes


### Own

 * [species](species.md)  <sub>0..1</sub>
     * Description: The species of an animal
     * Range: [Uriorcurie](types/Uriorcurie.md)
 * [breed](breed.md)  <sub>0..1</sub>
     * Description: The breed of an animal
     * Range: [Uriorcurie](types/Uriorcurie.md)
 * [color](color.md)  <sub>0..1</sub>
     * Description: The color of an animal
     * Range: [String](types/String.md)
 * [weight_in_mgs](weight_in_mgs.md)  <sub>0..1</sub>
     * Description: The weight of an animal in milligrams
     * Range: [String](types/String.md)

### Inherited from NamedThing:

 * [id](id.md)  <sub>1..1</sub>
     * Description: A unique identifier for a person
     * Range: [String](types/String.md)
 * [name](name.md)  <sub>0..1</sub>
     * Description: A human-readable name for a person
     * Range: [String](types/String.md)
 * [birth date](birth_date.md)  <sub>0..1</sub>
     * Description: Date on which a person is born
     * Range: [Date](types/Date.md)
 * [age_in_years](age_in_years.md)  <sub>0..1</sub>
     * Description: Number of years since birth
     * Range: [Integer](types/Integer.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Aliases:** | | pet |
| **Exact Mappings:** | | WIKIDATA:Q729 |
|  | | NCIT:C14182 |
| **Narrow Mappings:** | | FOODON:00003004 |

