
# Slot: weight_in_mgs


The weight of an animal in milligrams

URI: [linkml_tutorial:weight_in_mgs](https://w3id.org/tejasram365/linkml-tutorial/weight_in_mgs)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Animal](Animal.md)
