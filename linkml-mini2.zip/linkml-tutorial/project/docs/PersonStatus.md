
# Enum: PersonStatus


Range of the Status is being taken from existing ontology

URI: [linkml_tutorial:PersonStatus](https://w3id.org/tejasram365/linkml-tutorial/PersonStatus)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
| ALIVE | the person is living | PATO:0001421 |  |
| DEAD | the person is deceased | PATO:0001422 |  |
| UNKNOWN | the vital status is not known |  |  |

