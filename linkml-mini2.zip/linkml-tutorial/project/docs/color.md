
# Slot: color


The color of an animal

URI: [linkml_tutorial:color](https://w3id.org/tejasram365/linkml-tutorial/color)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Animal](Animal.md)
