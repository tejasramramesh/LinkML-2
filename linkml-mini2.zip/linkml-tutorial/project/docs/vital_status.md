
# Slot: vital_status


living or dead status

URI: [linkml_tutorial:vital_status](https://w3id.org/tejasram365/linkml-tutorial/vital_status)


## Domain and Range

None &#8594;  <sub>1..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Person](Person.md)
