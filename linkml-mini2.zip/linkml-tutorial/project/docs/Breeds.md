
# Enum: Breeds


Any breed from the VBO

URI: [linkml_tutorial:Breeds](https://w3id.org/tejasram365/linkml-tutorial/Breeds)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |

