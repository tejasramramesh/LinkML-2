
# Slot: primary_email


The main email address of a person

URI: [linkml_tutorial:primary_email](https://w3id.org/tejasram365/linkml-tutorial/primary_email)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Person](Person.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | schema:email |

