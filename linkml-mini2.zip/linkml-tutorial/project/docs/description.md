
# Slot: description


A human-readable description for a thing

URI: [linkml_tutorial:description](https://w3id.org/tejasram365/linkml-tutorial/description)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [NamedThing](NamedThing.md)
 * [Person](Person.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | schema:description |

