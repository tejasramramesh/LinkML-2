
# Class: PersonCollection


A collection of Persons

URI: [linkml_tutorial:PersonCollection](https://w3id.org/tejasram365/linkml-tutorial/PersonCollection)


[![img](https://yuml.me/diagram/nofunky;dir:TB/class/[Person]<entries%200..*-++[PersonCollection],[Person])](https://yuml.me/diagram/nofunky;dir:TB/class/[Person]<entries%200..*-++[PersonCollection],[Person])

## Attributes


### Own

 * [entries](entries.md)  <sub>0..\*</sub>
     * Description: A collection of things
     * Range: [Person](Person.md)
