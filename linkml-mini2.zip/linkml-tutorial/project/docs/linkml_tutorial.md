
# linkml-tutorial


**metamodel version:** 1.7.0

**version:** None


My first LinkML schema


### Classes

 * [AnimalCollection](AnimalCollection.md) - A collection of Animals
 * [NamedThing](NamedThing.md) - The most generic type of entity that has a name
     * [Animal](Animal.md) - Class for animals
     * [Person](Person.md) - Class for Person
 * [PersonCollection](PersonCollection.md) - A collection of Persons

### Mixins


### Slots

 * [age_in_years](age_in_years.md) - Number of years since birth
 * [animals](animals.md) - A collection of animals
 * [birth date](birth_date.md) - Date on which a person is born
 * [breed](breed.md) - The breed of an animal
 * [color](color.md) - The color of an animal
 * [entries](entries.md) - A collection of things
 * [id](id.md) - A unique identifier for a person
     * [Person➞id](Person_id.md) - this is a unique identifier for a person.
 * [name](name.md) - A human-readable name for a person
 * [pets](pets.md) - a collection of animals that lives with and is taken care of by a person.
 * [primary_email](primary_email.md) - The main email address of a person
 * [species](species.md) - The species of an animal
 * [vital_status](vital_status.md) - living or dead status
 * [weight_in_mgs](weight_in_mgs.md) - The weight of an animal in milligrams

### Enums

 * [Breeds](Breeds.md) - Any breed from the VBO
 * [PersonStatus](PersonStatus.md) - Range of the Status is being taken from existing ontology

### Subsets


### Types


#### Built in

 * **Bool**
 * **Curie**
 * **Decimal**
 * **ElementIdentifier**
 * **NCName**
 * **NodeIdentifier**
 * **URI**
 * **URIorCURIE**
 * **XSDDate**
 * **XSDDateTime**
 * **XSDTime**
 * **float**
 * **int**
 * **str**

#### Defined

 * [Boolean](types/Boolean.md)  (**Bool**)  - A binary (true or false) value
 * [Curie](types/Curie.md)  (**Curie**)  - a compact URI
 * [Date](types/Date.md)  (**XSDDate**)  - a date (year, month and day) in an idealized calendar
 * [DateOrDatetime](types/DateOrDatetime.md)  (**str**)  - Either a date or a datetime
 * [Datetime](types/Datetime.md)  (**XSDDateTime**)  - The combination of a date and time
 * [Decimal](types/Decimal.md)  (**Decimal**)  - A real number with arbitrary precision that conforms to the xsd:decimal specification
 * [Double](types/Double.md)  (**float**)  - A real number that conforms to the xsd:double specification
 * [Float](types/Float.md)  (**float**)  - A real number that conforms to the xsd:float specification
 * [Integer](types/Integer.md)  (**int**)  - An integer
 * [Ncname](types/Ncname.md)  (**NCName**)  - Prefix part of CURIE
 * [Nodeidentifier](types/Nodeidentifier.md)  (**NodeIdentifier**)  - A URI, CURIE or BNODE that represents a node in a model.
 * [Objectidentifier](types/Objectidentifier.md)  (**ElementIdentifier**)  - A URI or CURIE that represents an object in the model.
 * [String](types/String.md)  (**str**)  - A character string
 * [Time](types/Time.md)  (**XSDTime**)  - A time object represents a (local) time of day, independent of any particular day
 * [Uri](types/Uri.md)  (**URI**)  - a complete URI
 * [Uriorcurie](types/Uriorcurie.md)  (**URIorCURIE**)  - a URI or a CURIE
