
# Slot: entries




URI: [linkml_tutorial:personCollection__entries](https://w3id.org/tejasram365/linkml-tutorial/personCollection__entries)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Person](Person.md)

## Parents


## Children


## Used by

 * [PersonCollection](PersonCollection.md)
