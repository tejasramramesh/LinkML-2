
# Slot: breed


The breed of an animal

URI: [linkml_tutorial:breed](https://w3id.org/tejasram365/linkml-tutorial/breed)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Uriorcurie](types/Uriorcurie.md)

## Parents


## Children


## Used by

 * [Animal](Animal.md)
