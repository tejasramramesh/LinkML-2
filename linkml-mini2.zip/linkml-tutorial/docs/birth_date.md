# Slot: birth_date
_Date on which a person is born_


URI: [schema:birthDate](http://schema.org/birthDate)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[NamedThing](NamedThing.md) | The most generic type of entity that has a name
[Person](Person.md) | Class for Person
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:date](xsd:date)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: birth date
description: Date on which a person is born
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
slot_uri: schema:birthDate
alias: birth_date
domain_of:
- NamedThing
range: date

```
</details>