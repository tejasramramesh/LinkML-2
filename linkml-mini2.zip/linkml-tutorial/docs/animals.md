# Slot: animals
_A collection of animals_


URI: [linkml_tutorial:animals](https://w3id.org/tejasram365/linkml-tutorial/animals)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[AnimalCollection](AnimalCollection.md) | A collection of Animals






## Properties

* Range: [Animal](Animal.md)
* Multivalued: True








## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: animals
description: A collection of animals
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
multivalued: true
alias: animals
domain_of:
- AnimalCollection
range: Animal
inlined: true
inlined_as_list: true

```
</details>