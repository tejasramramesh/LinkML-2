# Enum: PersonStatus


_Range of the Status is being taken from existing ontology_


URI: [PersonStatus](PersonStatus)

## Permissible Values

| Value | Meaning | Description |
| --- | --- | --- |
| ALIVE | PATO:0001421 | the person is living |
| DEAD | PATO:0001422 | the person is deceased |
| UNKNOWN | None | the vital status is not known |









## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: PersonStatus
description: Range of the Status is being taken from existing ontology
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
permissible_values:
  ALIVE:
    text: ALIVE
    description: the person is living
    meaning: PATO:0001421
  DEAD:
    text: DEAD
    description: the person is deceased
    meaning: PATO:0001422
  UNKNOWN:
    text: UNKNOWN
    description: the vital status is not known

```
</details>
