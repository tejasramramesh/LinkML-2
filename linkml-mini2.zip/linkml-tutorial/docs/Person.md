# Class: Person
_Class for Person_




URI: [schema:Person](http://schema.org/Person)



```mermaid
 classDiagram
    class Person
      NamedThing <|-- Person
      
      Person : age_in_years
      Person : birth_date
      Person : id
      Person : name
      Person : pets
      Person : primary_email
      Person : vital_status
      
```





## Inheritance
* [NamedThing](NamedThing.md)
    * **Person**



## Slots

| Name | Cardinality and Range | Description | Inheritance |
| ---  | --- | --- | --- |
| [primary_email](primary_email.md) | 0..1 <br/> [xsd:string](xsd:string) | The main email address of a person | direct |
| [vital_status](vital_status.md) | 1..1 <br/> [xsd:string](xsd:string) | living or dead status | direct |
| [pets](pets.md) | 0..* <br/> [Animal](Animal.md) | a collection of animals that lives with and is taken care of by a person | direct |
| [id](id.md) | 1..1 <br/> [xsd:string](xsd:string) | this is a unique identifier for a person | [NamedThing](NamedThing.md) |
| [name](name.md) | 0..1 <br/> [xsd:string](xsd:string) | A human-readable name for a person | [NamedThing](NamedThing.md) |
| [birth_date](birth_date.md) | 0..1 <br/> [xsd:date](xsd:date) | Date on which a person is born | [NamedThing](NamedThing.md) |
| [age_in_years](age_in_years.md) | 0..1 <br/> [xsd:integer](xsd:integer) | Number of years since birth | [NamedThing](NamedThing.md) |





## Usages

| used by | used in | type | used |
| ---  | --- | --- | --- |
| [PersonCollection](PersonCollection.md) | [entries](entries.md) | range | [Person](Person.md) |






## Identifier and Mapping Information


### Valid ID Prefixes

Instances of this class *should* have identifiers with one of the following prefixes:

* orcid

* WIKIDATA








### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial





## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | schema:Person |
| native | linkml_tutorial:Person |
| exact | schema:Person, biolink:Person, foaf:Person, WIKIDATA:Q215627, WIKIDATA:Q5 |





## LinkML Source

<!-- TODO: investigate https://stackoverflow.com/questions/37606292/how-to-create-tabbed-code-blocks-in-mkdocs-or-sphinx -->

### Direct

<details>
```yaml
name: Person
id_prefixes:
- orcid
- WIKIDATA
description: Class for Person
from_schema: https://w3id.org/tejasram365/linkml-tutorial
exact_mappings:
- schema:Person
- biolink:Person
- foaf:Person
- WIKIDATA:Q215627
- WIKIDATA:Q5
rank: 1000
is_a: NamedThing
slots:
- primary_email
- vital_status
- pets
slot_usage:
  id:
    name: id
    description: this is a unique identifier for a person.
    domain_of:
    - NamedThing
    - NamedThing
class_uri: schema:Person

```
</details>

### Induced

<details>
```yaml
name: Person
id_prefixes:
- orcid
- WIKIDATA
description: Class for Person
from_schema: https://w3id.org/tejasram365/linkml-tutorial
exact_mappings:
- schema:Person
- biolink:Person
- foaf:Person
- WIKIDATA:Q215627
- WIKIDATA:Q5
rank: 1000
is_a: NamedThing
slot_usage:
  id:
    name: id
    description: this is a unique identifier for a person.
    domain_of:
    - NamedThing
    - NamedThing
attributes:
  primary_email:
    name: primary_email
    description: The main email address of a person
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:email
    alias: primary_email
    owner: Person
    domain_of:
    - Person
    range: string
    pattern: ^\S+@[\S+\.]+\S+
  vital_status:
    name: vital_status
    description: living or dead status
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    alias: vital_status
    owner: Person
    domain_of:
    - Person
    range: string
    required: true
  pets:
    name: pets
    description: a collection of animals that lives with and is taken care of by a
      person.
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    multivalued: true
    alias: pets
    owner: Person
    domain_of:
    - Person
    range: Animal
  id:
    name: id
    description: this is a unique identifier for a person.
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:identifier
    identifier: true
    alias: id
    owner: Person
    domain_of:
    - NamedThing
    - NamedThing
    range: string
    required: true
  name:
    name: name
    description: A human-readable name for a person
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:name
    alias: name
    owner: Person
    domain_of:
    - NamedThing
    range: string
  birth date:
    name: birth date
    description: Date on which a person is born
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:birthDate
    alias: birth_date
    owner: Person
    domain_of:
    - NamedThing
    range: date
  age_in_years:
    name: age_in_years
    description: Number of years since birth
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    alias: age_in_years
    owner: Person
    domain_of:
    - NamedThing
    range: integer
class_uri: schema:Person

```
</details>