# Slot: color
_The color of an animal_


URI: [linkml_tutorial:color](https://w3id.org/tejasram365/linkml-tutorial/color)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:string](xsd:string)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: color
description: The color of an animal
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
alias: color
domain_of:
- Animal
range: string

```
</details>