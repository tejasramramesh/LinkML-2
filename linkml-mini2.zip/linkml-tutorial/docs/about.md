# linkml-tutorial

My first LinkML schema


