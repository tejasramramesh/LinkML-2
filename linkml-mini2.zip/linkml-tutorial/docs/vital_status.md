# Slot: vital_status
_living or dead status_


URI: [linkml_tutorial:vital_status](https://w3id.org/tejasram365/linkml-tutorial/vital_status)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Person](Person.md) | Class for Person






## Properties

* Range: [xsd:string](xsd:string)
* Required: True








## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: vital_status
description: living or dead status
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
alias: vital_status
domain_of:
- Person
range: string
required: true

```
</details>