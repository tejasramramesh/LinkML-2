# Class: AnimalCollection
_A collection of Animals_




URI: [linkml_tutorial:AnimalCollection](https://w3id.org/tejasram365/linkml-tutorial/AnimalCollection)



```mermaid
 classDiagram
    class AnimalCollection
      AnimalCollection : animals
      
```




<!-- no inheritance hierarchy -->


## Slots

| Name | Cardinality and Range | Description | Inheritance |
| ---  | --- | --- | --- |
| [animals](animals.md) | 0..* <br/> [Animal](Animal.md) | A collection of animals | direct |









## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial





## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | linkml_tutorial:AnimalCollection |
| native | linkml_tutorial:AnimalCollection |





## LinkML Source

<!-- TODO: investigate https://stackoverflow.com/questions/37606292/how-to-create-tabbed-code-blocks-in-mkdocs-or-sphinx -->

### Direct

<details>
```yaml
name: AnimalCollection
description: A collection of Animals
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
slots:
- animals
tree_root: true

```
</details>

### Induced

<details>
```yaml
name: AnimalCollection
description: A collection of Animals
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
attributes:
  animals:
    name: animals
    description: A collection of animals
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    multivalued: true
    alias: animals
    owner: AnimalCollection
    domain_of:
    - AnimalCollection
    range: Animal
    inlined: true
    inlined_as_list: true
tree_root: true

```
</details>