# Class: NamedThing
_The most generic type of entity that has a name_



* __NOTE__: this is an abstract class and should not be instantiated directly


URI: [linkml_tutorial:NamedThing](https://w3id.org/tejasram365/linkml-tutorial/NamedThing)



```mermaid
 classDiagram
    class NamedThing
      NamedThing <|-- Person
      NamedThing <|-- Animal
      
      NamedThing : age_in_years
      NamedThing : birth_date
      NamedThing : id
      NamedThing : name
      
```





## Inheritance
* **NamedThing**
    * [Person](Person.md)
    * [Animal](Animal.md)



## Slots

| Name | Cardinality and Range | Description | Inheritance |
| ---  | --- | --- | --- |
| [id](id.md) | 1..1 <br/> [xsd:string](xsd:string) | A unique identifier for a person | direct |
| [name](name.md) | 0..1 <br/> [xsd:string](xsd:string) | A human-readable name for a person | direct |
| [birth_date](birth_date.md) | 0..1 <br/> [xsd:date](xsd:date) | Date on which a person is born | direct |
| [age_in_years](age_in_years.md) | 0..1 <br/> [xsd:integer](xsd:integer) | Number of years since birth | direct |









## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial





## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | linkml_tutorial:NamedThing |
| native | linkml_tutorial:NamedThing |





## LinkML Source

<!-- TODO: investigate https://stackoverflow.com/questions/37606292/how-to-create-tabbed-code-blocks-in-mkdocs-or-sphinx -->

### Direct

<details>
```yaml
name: NamedThing
description: The most generic type of entity that has a name
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
abstract: true
slots:
- id
- name
- birth date
- age_in_years

```
</details>

### Induced

<details>
```yaml
name: NamedThing
description: The most generic type of entity that has a name
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
abstract: true
attributes:
  id:
    name: id
    description: A unique identifier for a person
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:identifier
    identifier: true
    alias: id
    owner: NamedThing
    domain_of:
    - NamedThing
    range: string
    required: true
  name:
    name: name
    description: A human-readable name for a person
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:name
    alias: name
    owner: NamedThing
    domain_of:
    - NamedThing
    range: string
  birth date:
    name: birth date
    description: Date on which a person is born
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:birthDate
    alias: birth_date
    owner: NamedThing
    domain_of:
    - NamedThing
    range: date
  age_in_years:
    name: age_in_years
    description: Number of years since birth
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    alias: age_in_years
    owner: NamedThing
    domain_of:
    - NamedThing
    range: integer

```
</details>