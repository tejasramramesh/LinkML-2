# Slot: weight_in_mgs
_The weight of an animal in milligrams_


URI: [linkml_tutorial:weight_in_mgs](https://w3id.org/tejasram365/linkml-tutorial/weight_in_mgs)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:string](xsd:string)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: weight_in_mgs
description: The weight of an animal in milligrams
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
alias: weight_in_mgs
domain_of:
- Animal
range: string

```
</details>