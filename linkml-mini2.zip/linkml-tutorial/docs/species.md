# Slot: species
_The species of an animal_


URI: [linkml_tutorial:species](https://w3id.org/tejasram365/linkml-tutorial/species)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:anyURI](xsd:anyURI)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: species
description: The species of an animal
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
values_from:
- NCBITaxon
alias: species
domain_of:
- Animal
range: uriorcurie

```
</details>