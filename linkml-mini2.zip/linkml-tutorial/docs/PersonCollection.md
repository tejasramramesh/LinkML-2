# Class: PersonCollection
_A collection of Persons_




URI: [linkml_tutorial:PersonCollection](https://w3id.org/tejasram365/linkml-tutorial/PersonCollection)



```mermaid
 classDiagram
    class PersonCollection
      PersonCollection : entries
      
```




<!-- no inheritance hierarchy -->


## Slots

| Name | Cardinality and Range | Description | Inheritance |
| ---  | --- | --- | --- |
| [entries](entries.md) | 0..* <br/> [Person](Person.md) | A collection of things | direct |









## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial





## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | linkml_tutorial:PersonCollection |
| native | linkml_tutorial:PersonCollection |





## LinkML Source

<!-- TODO: investigate https://stackoverflow.com/questions/37606292/how-to-create-tabbed-code-blocks-in-mkdocs-or-sphinx -->

### Direct

<details>
```yaml
name: PersonCollection
description: A collection of Persons
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
slots:
- entries
tree_root: true

```
</details>

### Induced

<details>
```yaml
name: PersonCollection
description: A collection of Persons
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
attributes:
  entries:
    name: entries
    description: A collection of things
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    multivalued: true
    alias: entries
    owner: PersonCollection
    domain_of:
    - PersonCollection
    range: Person
    inlined: true
    inlined_as_list: true
tree_root: true

```
</details>