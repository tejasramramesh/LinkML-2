# Slot: name
_A human-readable name for a person_


URI: [schema:name](http://schema.org/name)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[NamedThing](NamedThing.md) | The most generic type of entity that has a name
[Person](Person.md) | Class for Person
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:string](xsd:string)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: name
description: A human-readable name for a person
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
slot_uri: schema:name
alias: name
domain_of:
- NamedThing
range: string

```
</details>