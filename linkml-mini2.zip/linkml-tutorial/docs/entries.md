# Slot: entries
_A collection of things_


URI: [linkml_tutorial:entries](https://w3id.org/tejasram365/linkml-tutorial/entries)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[PersonCollection](PersonCollection.md) | A collection of Persons






## Properties

* Range: [Person](Person.md)
* Multivalued: True








## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: entries
description: A collection of things
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
multivalued: true
alias: entries
domain_of:
- PersonCollection
range: Person
inlined: true
inlined_as_list: true

```
</details>