# Slot: id
_A unique identifier for a person_


URI: [schema:identifier](http://schema.org/identifier)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[NamedThing](NamedThing.md) | The most generic type of entity that has a name
[Person](Person.md) | Class for Person
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:string](xsd:string)
* Required: True








## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: id
description: A unique identifier for a person
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
slot_uri: schema:identifier
identifier: true
alias: id
domain_of:
- NamedThing
range: string
required: true

```
</details>