# Slot: pets
_a collection of animals that lives with and is taken care of by a person._


URI: [linkml_tutorial:pets](https://w3id.org/tejasram365/linkml-tutorial/pets)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Person](Person.md) | Class for Person






## Properties

* Range: [Animal](Animal.md)
* Multivalued: True








## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: pets
description: a collection of animals that lives with and is taken care of by a person.
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
multivalued: true
alias: pets
domain_of:
- Person
range: Animal

```
</details>