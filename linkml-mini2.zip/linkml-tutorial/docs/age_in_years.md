# Slot: age_in_years
_Number of years since birth_


URI: [linkml_tutorial:age_in_years](https://w3id.org/tejasram365/linkml-tutorial/age_in_years)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[NamedThing](NamedThing.md) | The most generic type of entity that has a name
[Person](Person.md) | Class for Person
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:integer](xsd:integer)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: age_in_years
description: Number of years since birth
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
alias: age_in_years
domain_of:
- NamedThing
range: integer

```
</details>