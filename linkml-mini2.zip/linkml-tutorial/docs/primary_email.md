# Slot: primary_email
_The main email address of a person_


URI: [schema:email](http://schema.org/email)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Person](Person.md) | Class for Person






## Properties

* Range: [xsd:string](xsd:string)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: primary_email
description: The main email address of a person
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
slot_uri: schema:email
alias: primary_email
domain_of:
- Person
range: string
pattern: ^\S+@[\S+\.]+\S+

```
</details>