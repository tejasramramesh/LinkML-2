# Class: Animal
_Class for animals_




URI: [linkml_tutorial:Animal](https://w3id.org/tejasram365/linkml-tutorial/Animal)



```mermaid
 classDiagram
    class Animal
      NamedThing <|-- Animal
      
      Animal : age_in_years
      Animal : birth_date
      Animal : breed
      Animal : color
      Animal : id
      Animal : name
      Animal : species
      Animal : weight_in_mgs
      
```





## Inheritance
* [NamedThing](NamedThing.md)
    * **Animal**



## Slots

| Name | Cardinality and Range | Description | Inheritance |
| ---  | --- | --- | --- |
| [species](species.md) | 0..1 <br/> [xsd:anyURI](xsd:anyURI) | The species of an animal | direct |
| [breed](breed.md) | 0..1 <br/> [xsd:anyURI](xsd:anyURI) | The breed of an animal | direct |
| [color](color.md) | 0..1 <br/> [xsd:string](xsd:string) | The color of an animal | direct |
| [weight_in_mgs](weight_in_mgs.md) | 0..1 <br/> [xsd:string](xsd:string) | The weight of an animal in milligrams | direct |
| [id](id.md) | 1..1 <br/> [xsd:string](xsd:string) | A unique identifier for a person | [NamedThing](NamedThing.md) |
| [name](name.md) | 0..1 <br/> [xsd:string](xsd:string) | A human-readable name for a person | [NamedThing](NamedThing.md) |
| [birth_date](birth_date.md) | 0..1 <br/> [xsd:date](xsd:date) | Date on which a person is born | [NamedThing](NamedThing.md) |
| [age_in_years](age_in_years.md) | 0..1 <br/> [xsd:integer](xsd:integer) | Number of years since birth | [NamedThing](NamedThing.md) |





## Usages

| used by | used in | type | used |
| ---  | --- | --- | --- |
| [Person](Person.md) | [pets](pets.md) | range | [Animal](Animal.md) |
| [AnimalCollection](AnimalCollection.md) | [animals](animals.md) | range | [Animal](Animal.md) |




## Aliases


* pet



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial





## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | linkml_tutorial:Animal |
| native | linkml_tutorial:Animal |
| exact | WIKIDATA:Q729, NCIT:C14182 |
| narrow | FOODON:00003004 |





## LinkML Source

<!-- TODO: investigate https://stackoverflow.com/questions/37606292/how-to-create-tabbed-code-blocks-in-mkdocs-or-sphinx -->

### Direct

<details>
```yaml
name: Animal
description: Class for animals
from_schema: https://w3id.org/tejasram365/linkml-tutorial
aliases:
- pet
exact_mappings:
- WIKIDATA:Q729
- NCIT:C14182
narrow_mappings:
- FOODON:00003004
rank: 1000
is_a: NamedThing
slots:
- species
- breed
- color
- weight_in_mgs
unique_keys:
  main:
    unique_key_name: main
    unique_key_slots:
    - name
    - birth date
    description: An animal is also be uniquely identified by their name and birth
      date
rules:
- postconditions:
    description: At least one of breed or species should be populated.
    any_of:
    - slot_conditions:
        breed:
          name: breed
          required: true
    - slot_conditions:
        species:
          name: species
          required: true

```
</details>

### Induced

<details>
```yaml
name: Animal
description: Class for animals
from_schema: https://w3id.org/tejasram365/linkml-tutorial
aliases:
- pet
exact_mappings:
- WIKIDATA:Q729
- NCIT:C14182
narrow_mappings:
- FOODON:00003004
rank: 1000
is_a: NamedThing
attributes:
  species:
    name: species
    description: The species of an animal
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    values_from:
    - NCBITaxon
    alias: species
    owner: Animal
    domain_of:
    - Animal
    range: uriorcurie
  breed:
    name: breed
    description: The breed of an animal
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    values_from:
    - VBO
    alias: breed
    owner: Animal
    domain_of:
    - Animal
    range: uriorcurie
  color:
    name: color
    description: The color of an animal
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    alias: color
    owner: Animal
    domain_of:
    - Animal
    range: string
  weight_in_mgs:
    name: weight_in_mgs
    description: The weight of an animal in milligrams
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    alias: weight_in_mgs
    owner: Animal
    domain_of:
    - Animal
    range: string
  id:
    name: id
    description: A unique identifier for a person
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:identifier
    identifier: true
    alias: id
    owner: Animal
    domain_of:
    - NamedThing
    range: string
    required: true
  name:
    name: name
    description: A human-readable name for a person
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:name
    alias: name
    owner: Animal
    domain_of:
    - NamedThing
    range: string
  birth date:
    name: birth date
    description: Date on which a person is born
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    slot_uri: schema:birthDate
    alias: birth_date
    owner: Animal
    domain_of:
    - NamedThing
    range: date
  age_in_years:
    name: age_in_years
    description: Number of years since birth
    from_schema: https://w3id.org/tejasram365/linkml-tutorial
    rank: 1000
    alias: age_in_years
    owner: Animal
    domain_of:
    - NamedThing
    range: integer
unique_keys:
  main:
    unique_key_name: main
    unique_key_slots:
    - name
    - birth date
    description: An animal is also be uniquely identified by their name and birth
      date
rules:
- postconditions:
    description: At least one of breed or species should be populated.
    any_of:
    - slot_conditions:
        breed:
          name: breed
          required: true
    - slot_conditions:
        species:
          name: species
          required: true

```
</details>