# linkml-tutorial

My first LinkML schema

URI: https://w3id.org/tejasram365/linkml-tutorial

