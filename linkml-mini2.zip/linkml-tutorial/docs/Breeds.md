# Enum: Breeds


_Any breed from the VBO_


URI: [Breeds](Breeds)


_This is a dynamic enum_








## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: Breeds
description: Any breed from the VBO
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
reachable_from:
  source_ontology: bioregistry:vbo
  source_nodes:
  - VBO:00000000
  relationship_types:
  - rdfs:subClassOf
  is_direct: false

```
</details>
