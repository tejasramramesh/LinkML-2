# Slot: breed
_The breed of an animal_


URI: [linkml_tutorial:breed](https://w3id.org/tejasram365/linkml-tutorial/breed)



<!-- no inheritance hierarchy -->




## Applicable Classes

| Name | Description |
| --- | --- |
[Animal](Animal.md) | Class for animals






## Properties

* Range: [xsd:anyURI](xsd:anyURI)







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/tejasram365/linkml-tutorial




## LinkML Source

<details>
```yaml
name: breed
description: The breed of an animal
from_schema: https://w3id.org/tejasram365/linkml-tutorial
rank: 1000
values_from:
- VBO
alias: breed
domain_of:
- Animal
range: uriorcurie

```
</details>