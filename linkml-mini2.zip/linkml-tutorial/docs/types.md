# types

Shared type definitions for the core LinkML mode and metamodel

URI: https://w3id.org/linkml/types

