# Examples of use of linkml_tutorial

This folder contains example data conforming to linkml_tutorial

The source for these is in [src/data](../src/data/examples)